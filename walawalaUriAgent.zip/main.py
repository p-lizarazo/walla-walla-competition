"""Claude's Agent Jeopardy runner.

Continuous loop: poll the live board, run several tiles concurrently, give the
model real tools (shell + HTTP) instead of asking it to answer from memory,
and never let a verified answer round-trip back through the model as text
before it's submitted.

Every team shares the same measured budget — 95,000 tokens/minute, checked
live via GET /api/me — so tokens-per-solve, not worker count, is what caps
real throughput once enough workers exist to keep that pipe full. Two things
here exist because of that: the system prompt + tool schemas are identical on
every single call this agent ever makes, so they're marked as a cached
("ephemeral") prefix — repeat calls should read that prefix from cache
instead of paying full price for it every time. And tool-output truncation is
kept tight on purpose, with the tools themselves telling the model to sample
files/pages instead of dumping them whole.

Env knobs (all optional):
    VERBOSE=1            print prompts, tool calls, and raw submit responses
    TASK_FILTER=A,B,C     attempt exactly these tile ids
    MAX_TILES=N           cap how many distinct tiles are ever attempted
    WORKERS=8              concurrent tile-solving threads
    CODE_WORKERS=3          concurrent shell/code executions (CPU budget)
    MAX_TURNS=14            tool-call rounds before a tile is abandoned
"""
from __future__ import annotations

import os
import subprocess
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor

import requests

import jeopardy as jp

VERBOSE = os.environ.get("VERBOSE") == "1"
TASK_FILTER = {
    t.strip() for t in os.environ.get("TASK_FILTER", "").split(",") if t.strip()
}
MAX_TILES = int(os.environ.get("MAX_TILES", "0"))
WORKERS = int(os.environ.get("WORKERS", "8"))
CODE_WORKERS = int(os.environ.get("CODE_WORKERS", "3"))
MAX_TURNS = int(os.environ.get("MAX_TURNS", "14"))
POLL_SECONDS = float(os.environ.get("POLL_SECONDS", "1.5"))
MIN_SUBMIT_GAP = 3.2          # server allows 1 submit / 3s per team
DEFAULT_RETRY = 12.0          # fallback if a response carries no retry_in

# Heavy Compute tiles take real wall-clock time to search/optimize; don't let
# them soak up every worker slot in the opening seconds when cheap tiles in
# other categories are still unclaimed.
CATEGORY_WEIGHT = {
    "Cryptic": 0,
    "Ancient Scrolls": 1,
    "Ship It": 2,
    "Needle in the Haystack": 3,
    "The Dark Web": 4,
    "Heavy Compute": 5,
}

CATEGORY_HINT = {
    "Cryptic": "Inspect the raw bytes with code; don't guess an encoding by eye.",
    "Ancient Scrolls": "Parse the document with code — track amendments, dates, cross-references exactly.",
    "Ship It": "Read every file, run the project's own tests, make the smallest fix that passes them.",
    "Needle in the Haystack": "Load the data with a real parser and compute the answer exactly, not by eyeballing.",
    "The Dark Web": "Use http_request for every step so cookies persist across the whole session.",
    "Heavy Compute": "Write and run an actual search/optimization; check the result against the stated threshold before answering.",
}

# Identical on every call this agent ever makes (no tile-specific content),
# so it's marked as a cached prefix below — see the module docstring.
SYSTEM_PROMPT = (
    "You are solving one Agent Jeopardy tile using tools. Rules:\n"
    "1. Never invent file contents or HTTP responses you have not actually "
    "seen via a tool call.\n"
    "2. Verify your result with code before finishing — re-derive or "
    "re-check it, don't just eyeball it.\n"
    "3. Keep tool output small: sample, grep, or summarize with code instead "
    "of printing whole files or full HTTP bodies. You're working under a "
    "shared per-minute token budget, so a smaller tool call is a faster "
    "answer, for you and for your team's other tiles running at the same "
    "time.\n"
    "4. When confident, call submit_answer with a shell command whose stdout "
    "is EXACTLY the final answer and nothing else. That command's stdout — "
    "never your own retyped text — is what gets submitted, so compute and "
    "print it; don't hand-transcribe a value you already derived."
)

TOOLS = [
    {
        "name": "run_command",
        "description": (
            "Run a shell command in this tile's working directory (the task's "
            "downloaded files live there). Use it to inspect real files, "
            "compute exact answers, extract archives, or run tests. Output is "
            "truncated if huge, so prefer writing a script over dumping raw files."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
        },
    },
    {
        "name": "http_request",
        "description": (
            "Make an HTTP request. A cookie session is kept for this tile only "
            "and persists automatically between calls, so login/session flows work."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "method": {"type": "string"},
                "url": {"type": "string"},
                "params": {"type": "object"},
                "data": {"type": "object"},
                "json": {"type": "object"},
                "headers": {"type": "object"},
            },
            "required": ["method", "url"],
        },
    },
    {
        "name": "submit_answer",
        "description": (
            "Finish the tile. Give a shell command whose stdout is EXACTLY the "
            "verified answer and nothing else. The command's stdout — not your "
            "own text — is what gets submitted, so compute/print it, don't retype "
            "a value you already derived."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
        },
        # Cache breakpoint: everything in `tools` up to and including this
        # entry is an identical, reusable prefix across every call, every
        # tile, all round. One cache write, many cheap cache reads.
        "cache_control": {"type": "ephemeral"},
    },
]

_code_slots = threading.Semaphore(CODE_WORKERS)
_submit_lock = threading.Lock()
_last_submit = 0.0


def run_shell(command: str, cwd) -> tuple[int, str, str]:
    with _code_slots:
        try:
            r = subprocess.run(
                ["bash", "-lc", command], cwd=cwd,
                text=True, capture_output=True, timeout=60,
            )
            return r.returncode, r.stdout, r.stderr
        except subprocess.TimeoutExpired as exc:
            return 124, exc.stdout or "", "command timed out after 60s"


def do_http(session: requests.Session, args: dict) -> str:
    method = str(args.get("method", "")).upper()
    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"}:
        return f"unsupported method: {method!r}"
    url = str(args.get("url", ""))
    if not url.startswith(("http://", "https://")):
        return "url must start with http:// or https://"
    resp = session.request(
        method, url,
        params=args.get("params"), data=args.get("data"),
        json=args.get("json"), headers=args.get("headers"),
        timeout=30,
    )
    headers = "\n".join(f"{k}: {v}" for k, v in resp.headers.items())
    return f"HTTP {resp.status_code}\nURL: {resp.url}\n{headers}\n\n{resp.text[:6000]}"


def gated_submit(task_id: str, answer: str) -> dict:
    """Serializes submissions to respect the team-wide 1-per-3s limit, and
    re-checks the tile is still open right before spending that slot."""
    global _last_submit
    with _submit_lock:
        wait = MIN_SUBMIT_GAP - (time.monotonic() - _last_submit)
        if wait > 0:
            time.sleep(wait)
        still_open = {t["id"] for t in jp.open_tiles(jp.board())}
        if task_id not in still_open:
            return {"result": "already_claimed"}
        result = jp.submit(task_id, answer)
        _last_submit = time.monotonic()
        return result


def solve(task_id: str, attempt_number: int) -> dict:
    # No lock here on purpose: jp's HTTP session is safe under concurrent use
    # (urllib3's connection pool handles that), and fetching a tile's own
    # task/files is independent of every other tile's. Serializing this
    # through a shared lock — an easy mistake under time pressure — would
    # turn "N tiles start at once" into "N tiles start one at a time."
    detail = jp.task(task_id)
    cwd = jp.workdir(task_id)
    files = jp.fetch_files(task_id, detail)

    answer_format = detail.get("answer_format", "exact")
    # Everything generic (never invent, verify, how to finish) lives in the
    # cached SYSTEM_PROMPT instead — this is just what's actually specific to
    # this tile, so it stays short and doesn't bust the cache with prose that
    # never changes between tiles.
    prompt = (
        f"{detail['prompt']}\n\n"
        f"Files already downloaded into your working directory: {files or 'none'}\n"
        f"Answer format the checker expects: {answer_format}\n"
        f"Category tip: {CATEGORY_HINT.get(detail.get('category'), '')}"
    )
    if attempt_number > 1:
        prompt += (
            "\n\nA previous submission for this tile was wrong. Question your "
            "prior assumptions and re-derive the answer independently — don't "
            "just resubmit the same reasoning."
        )
    if VERBOSE:
        jp.log(f"{task_id} [{detail.get('category')} {detail.get('points')}pt] "
               f"attempt {attempt_number} prompt:\n{prompt}\n---")

    client = jp.anthropic_client()
    session = requests.Session()
    messages = [{"role": "user", "content": prompt}]
    final_answer = ""

    for _ in range(MAX_TURNS):
        response = client.messages.create(
            model=jp.MODEL, max_tokens=4096,
            system=[{
                "type": "text", "text": SYSTEM_PROMPT,
                "cache_control": {"type": "ephemeral"},
            }],
            tools=TOOLS, messages=messages,
        )
        messages.append({"role": "assistant", "content": response.content})
        calls = [b for b in response.content if b.type == "tool_use"]
        if not calls:
            break  # model stopped without submitting; treat as no answer

        tool_results = []
        for call in calls:
            if VERBOSE:
                jp.log(f"{task_id} tool={call.name} input={call.input}")
            if call.name == "http_request":
                try:
                    output = do_http(session, call.input)
                except requests.RequestException as exc:
                    output = f"http request failed: {exc!r}"
            else:
                code, out, err = run_shell(call.input.get("command", ""), cwd)
                if call.name == "submit_answer" and code == 0 and out.strip():
                    final_answer = out.strip()
                    break
                output = f"exit code: {code}\n{(out + err)[-6000:] or '(no output)'}"
            tool_results.append({
                "type": "tool_result", "tool_use_id": call.id, "content": output,
            })
        if final_answer:
            break
        messages.append({"role": "user", "content": tool_results})
    else:
        return {"result": "no_answer", "reason": f"exceeded {MAX_TURNS} tool turns"}

    if not final_answer:
        return {"result": "no_answer", "reason": "model stopped without submitting"}

    result = gated_submit(task_id, final_answer)
    jp.log(f"{task_id}: {final_answer[:80]!r} -> {result.get('result')}")
    if VERBOSE:
        jp.log(f"{task_id} raw submit response: {result}")
    return result


def rank(tiles: list[dict]) -> list[dict]:
    if TASK_FILTER:
        tiles = [t for t in tiles if t["id"] in TASK_FILTER]
    tiles.sort(key=lambda t: (
        CATEGORY_WEIGHT.get(t.get("category"), 9),
        -t.get("points", 0),
    ))
    return tiles[:MAX_TILES] if MAX_TILES else tiles


TERMINAL = {"correct", "already_claimed", "voided", "forbidden",
            "wrong_phase", "unknown_task"}


def main() -> None:
    active: dict[Future, str] = {}
    attempts: dict[str, int] = {}
    retry_at: dict[str, float] = {}
    done: set[str] = set()
    last_status = None

    jp.log(f"agent up: {WORKERS} tile workers, {CODE_WORKERS} code slots, "
           f"max {MAX_TURNS} tool turns/tile")

    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        while True:
            now = time.monotonic()

            for fut in [f for f in active if f.done()]:
                task_id = active.pop(fut)
                try:
                    result = fut.result()
                    outcome = result.get("result")
                    if outcome in TERMINAL:
                        done.add(task_id)
                    else:
                        # incorrect / locked_out / rate_limited / no_answer —
                        # all recoverable. Respect the server's own cooldown
                        # when it tells us one; otherwise back off a bit.
                        retry_at[task_id] = now + float(
                            result.get("retry_in", DEFAULT_RETRY)
                        )
                except jp.AuthError:
                    raise
                except Exception as exc:  # one tile's bug must not kill the agent
                    jp.log(f"{task_id}: crashed — {exc!r}; retrying in {DEFAULT_RETRY}s")
                    retry_at[task_id] = now + DEFAULT_RETRY

            try:
                board = jp.board()
                tiles = rank(jp.open_tiles(board))
            except jp.AuthError:
                raise
            except Exception as exc:
                jp.log(f"board poll failed: {exc!r}")
                time.sleep(POLL_SECONDS)
                continue

            status = (board.get("phase"), len(tiles), len(active))
            if status != last_status:
                jp.log(f"phase={status[0]} open_tiles={status[1]} active={status[2]}")
                last_status = status

            busy = set(active.values())
            free = WORKERS - len(active)
            for tile in tiles:
                if free <= 0:
                    break
                tid = tile["id"]
                if tid in busy or tid in done or retry_at.get(tid, 0) > now:
                    continue
                attempts[tid] = attempts.get(tid, 0) + 1
                fut = pool.submit(solve, tid, attempts[tid])
                active[fut] = tid
                busy.add(tid)
                free -= 1
                jp.log(f"{tid}: scheduled ({tile.get('category')}, "
                       f"{tile.get('points')}pt, attempt {attempts[tid]})")

            time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    try:
        main()
    except jp.AuthError as exc:
        raise SystemExit(f"[auth] {exc}")
